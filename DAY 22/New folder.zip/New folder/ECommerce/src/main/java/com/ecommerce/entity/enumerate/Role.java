package com.ecommerce.entity.enumerate;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role {
    ADMIN,
    CUSTOMER
}